import hashlib,json,os,pathlib,re,shutil,subprocess
base=pathlib.Path(__file__).parent
deps=base/'build-deps/root'
repo=base/'banjos-backpack'
app=base/'BanjoBackpack.AppDir'
out=base/'deliverables'
out.mkdir(exist_ok=True)
for name,digest in json.loads((repo/'lib/Linux/SHA256.json').read_text()).items():
    if hashlib.sha256((repo/'bin/Linux'/name).read_bytes()).hexdigest()!=digest:
        raise RuntimeError('Refusing to package unverified graphics library: '+name)
if app.exists(): shutil.rmtree(app)
(app/'usr/bin').mkdir(parents=True)
shutil.copy2(deps/'usr/bin/mono-sgen',app/'usr/bin/mono-sgen')
for part in ['4.5','gac']:
    shutil.copytree(deps/'usr/lib/mono'/part,app/'usr/lib/mono'/part,symlinks=True)
shutil.copytree(deps/'etc/mono',app/'etc/mono',symlinks=True)
shutil.copytree(repo/'bin/Linux',app/'usr/lib/banjos-backpack',ignore=shutil.ignore_patterns('*.resources','*.mdb','RomTest*','StatsTest*'))
shutil.copytree(deps/'usr/share/fonts/truetype/dejavu',app/'usr/share/fonts/truetype/dejavu')
env=os.environ.copy()
env['LD_LIBRARY_PATH']=':'.join(str(deps/p) for p in ['usr/lib','usr/lib/x86_64-linux-gnu','lib/x86_64-linux-gnu'])
paths=[deps/p for p in ['usr/lib','usr/lib/x86_64-linux-gnu','lib/x86_64-linux-gnu']]
excluded=re.compile(r'^(lib(c|m|pthread|dl|rt|resolv|util|anl|nss_.*)\.so|ld-linux|libstdc\+\+|libgcc_s|lib(GL|GLX|GLdispatch|EGL|GLES|drm|gbm)\.)')
selected={}
def add(file,name=None):
    name=name or file.name
    if name in selected or excluded.match(name):return
    file=file.resolve()
    if not file.exists():raise RuntimeError('Missing native library '+str(file))
    selected[name]=file
    text=subprocess.check_output(['ldd',str(file)],env=env,text=True)
    for line in text.splitlines():
        if 'not found' in line:raise RuntimeError('Unresolved: '+line)
        m=re.match(r'\s*(\S+) => (\S+)',line)
        if m and m[2].startswith('/'):add(pathlib.Path(m[2]),m[1])
for name in ['libMonoPosixHelper.so','libmono-native.so','libmono-btls-shared.so','libgdiplus.so.0','libGLU.so.1',
             'libX11.so.6','libXext.so.6','libXrender.so.1','libXinerama.so.1','libXi.so.6','libXrandr.so.2',
             'libXcursor.so.1','libXfixes.so.3','libXxf86vm.so.1','libSM.so.6','libICE.so.6']:
    source=next((p/name for p in paths if (p/name).exists()),None)
    if source is None:raise RuntimeError('Missing '+name)
    add(source,name)
native=app/'usr/lib/native';native.mkdir()
for name,src in selected.items():shutil.copy2(src,native/name)
# Mono expands $mono_libdir relative to usr/bin; use the common native folder.
config=app/'etc/mono/config'
config.write_text(config.read_text().replace('$mono_libdir/','$mono_libdir/native/'))
(app/'etc/fonts').mkdir()
(app/'etc/fonts/fonts.conf').write_text('''<?xml version="1.0"?>
<!DOCTYPE fontconfig SYSTEM "urn:fontconfig:fonts.dtd">
<fontconfig><dir>/usr/share/fonts</dir><dir>/usr/local/share/fonts</dir>
<dir prefix="xdg">fonts</dir><dir prefix="relative">../../usr/share/fonts/truetype/dejavu</dir>
<cachedir prefix="xdg">fontconfig</cachedir><config><rescan><int>30</int></rescan></config></fontconfig>
''')
(app/'AppRun').write_text('''#!/bin/sh
set -eu
APPDIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export APPDIR
export LD_LIBRARY_PATH="$APPDIR/usr/lib/native${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export MONO_CFG_DIR="$APPDIR/etc"
export MONO_PATH="$APPDIR/usr/lib/mono/4.5"
export FONTCONFIG_FILE="$APPDIR/etc/fonts/fonts.conf"
exec "$APPDIR/usr/bin/mono-sgen" "$APPDIR/usr/lib/banjos-backpack/BanjoKazooieLevelEditor.exe" "$@"
''')
(app/'AppRun').chmod(0o755)
(app/'banjos-backpack.desktop').write_text('''[Desktop Entry]
Type=Application
Name=Banjo's Backpack
Comment=Banjo-Kazooie level editor — Linux preview
Exec=AppRun
Icon=banjos-backpack
Terminal=false
Categories=Graphics;3DGraphics;Development;
StartupWMClass=BanjoKazooieLevelEditor
''')
shutil.copy2(repo/'appicon.png',app/'banjos-backpack.png')
os.symlink('banjos-backpack.png',app/'.DirIcon')
licenses=app/'usr/share/doc/banjos-backpack';licenses.mkdir(parents=True)
shutil.copy2(repo/'LICENSE',licenses/'LICENSE')
shutil.copy2(base/'build-deps/packages.json',licenses/'build-packages.json')
for p in (deps/'usr/share/doc').glob('*/copyright'):
    shutil.copy2(p,licenses/(p.parent.name+'.copyright'))
(licenses/'native-libraries.json').write_text(json.dumps({n:str(p.relative_to(deps)) if p.is_relative_to(deps) else str(p) for n,p in selected.items()},indent=2))
runtime=base/'upstream-release/appimage-runtime'
image=out/'Banjos-Backpack-Linux-preview-1-x86_64.AppImage'
squash=base/'build-deps/appimage.squashfs'
subprocess.run([str(deps/'usr/bin/mksquashfs'),str(app),str(squash),'-noappend','-comp','gzip','-b','1048576','-all-root','-no-xattrs','-processors','2'],env=env,check=True,stdout=subprocess.DEVNULL)
with image.open('wb') as dst:
    for p in [runtime,squash]:
        with p.open('rb') as src:shutil.copyfileobj(src,dst)
image.chmod(0o755)
print('Packaged',image.name,round(image.stat().st_size/2**20,1),'MiB;',len(selected),'native libraries')
