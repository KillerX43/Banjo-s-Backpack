#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
python3 bootstrap_deps.py
python3 - <<'PY'
import hashlib,json,pathlib
root=pathlib.Path('upstream-release')
for name,digest in json.loads((root/'SHA256.json').read_text()).items():
    if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:
        raise SystemExit('Checksum mismatch: '+name)
PY
build-deps/root/usr/lib/p7zip/7z x -y -oupstream-release/extracted upstream-release/backpack.7z >/dev/null
python3 build_linux.py
python3 package_appimage.py
deliverables/Banjos-Backpack-Linux-preview-1-x86_64.AppImage --appimage-extract-and-run --self-test
