# Banjo's Backpack — Linux preview 1 (collectible totals update)

A self-contained x86-64 Linux AppImage built from RareExports/Banjo-s-Backpack,
commit `89b308a5b5ba923adb2373da01f940ca67c0dade`. This runs the editor through its
bundled Linux Mono runtime. Wine, Proton and a separate Mono installation are
not needed. No game ROM is included.

## Steam Deck / SteamOS

1. Switch to Desktop Mode and download the `.AppImage`.
2. Right-click it → Properties → Permissions → enable **Is executable**.
3. Open it. Choose **File → Open ROM** and select a **copy** of your
   Banjo-Kazooie US v1.0, big-endian `.z64` ROM. The editor can modify ROMs.

The equivalent Konsole commands, from the download folder, are:

```sh
chmod +x Banjos-Backpack-Linux-preview-1-x86_64.AppImage
./Banjos-Backpack-Linux-preview-1-x86_64.AppImage
```

If launch reports a FUSE or mounting error, run this instead; it extracts and
launches the same bundled application without installing anything:

```sh
./Banjos-Backpack-Linux-preview-1-x86_64.AppImage --appimage-extract-and-run
```

For a Steam shortcut, add the AppImage as a non-Steam application. Leave
**Force the use of a specific Steam Play compatibility tool** unchecked.
If needed, put `--appimage-extract-and-run` in the shortcut's launch options.
Desktop Mode with a mouse and keyboard is the intended editing environment;
the original mouse/keyboard interface has been retained.

## Setup-file regression fix (2026-09-07)

The shutdown rebuild accidentally substituted Ubuntu's OpenTK binaries for the
working editor libraries. Both report version 1.1, but the replacement throws a
graphics exception during level rendering. This revision restores the verified
libraries and pins their hashes in the source build, keeping the shutdown fix.

The ROM regression now runs the actual Open Setup File From Rom menu, loads MM,
checks all nine worlds' collectibles, renders the scene/HUD, and saves and reads
back a moved note. Use tests/run_rom_test.py with an unpacked AppImage directory
and your own ROM file; it makes a disposable test copy and never bundles the ROM.

## SteamOS close/relaunch fix (2026-09-07)

This revision explicitly closes the single-instance lock when the main editor
finishes, including error paths. Animation processing now uses an owned progress
window on the editor's UI thread, so an abandoned foreground dialog thread cannot
keep the application alive. An active second copy receives a readable message.
The existing lock file is intentionally retained; its presence alone does not
prevent startup.

If the older build is already stuck after its window closed, restart the device
once before launching this revision. Replace the old AppImage at the same path to
keep an existing Steam shortcut. Your ROM and user data do not need to be deleted.

## What is included

- The full editor compiled from the supplied repository, including its level,
  model, texture, sprite, text and MIDI editor code.
- Mono 6.8, Linux OpenTK, GDI+ and 51 native supporting libraries; the host
  supplies its display server and graphics driver.
- Required menus, object/setup/animation tables and other editor resources
  from the upstream 1.0.5 release archive, paired with the newer source commit.
- Managed replacements for Windows gzip and ROM-checksum helpers.
- Managed 16/256-color palette reduction replacing Windows-only Magick.NET.
- Linux file paths, writable user data, startup error logging and protection
  against two editor processes sharing the same temporary files.

## Collectibles and level objects

Select **File → Open Setup File → MM - Mumbo's Mountain** after opening a ROM.
The viewport displays placed objects and notes, with Jinjo icons at the lower
right and Jiggy/note/honeycomb/Mumbo-token counters at the lower left.
The update fixes Linux helper-model paths and the HUD projection, isolates HUD
rendering from scene state, and counts other scenes in the same world without
stopping on duplicate keys or displaying background camera warnings.

The counters now include standard-game scripted rewards (huts, puzzles and
character rewards), and deduplicate placed Jiggies by their reward flags across
scenes and seasons. All nine main worlds in the supplied US v1.0 ROM verify as
100 notes, 10 Jiggies and five Jinjos, including MM's hut-spawned green Jinjo.
Deleting a placed note or a supported reward-producing actor updates the totals.
Spiral Mountain, Furnace Fun/final-battle and cutscene areas are not assigned
main-world totals. Arbitrary changes to the game's scripts are not simulated.

## Verification and remaining limits

Verified on x86-64 Ubuntu 24.04 using the **final AppImage**, without inheriting
build-directory library paths:

- Linux window startup and OpenGL 4.5 compatibility context.
- Parsing and rendering the bundled Banjo model; the framebuffer contains
  visible model pixels.
- Opening and closing the About dialog.
- Seven compression/decompression round trips, including unaligned sizes.
- All five supported N64 CIC checksum variants against independent C vectors.
- 16-color and 256-color image conversion.
- AppImage extraction-and-run and bundled runtime startup.
- Opening and extending a disposable copy of the supplied US v1.0 ROM.
- Selecting Mumbo's Mountain through the setup menu, rendering notes and the
  Jinjo/collectible HUD, and confirming all nine main worlds have correct collectible totals.
- Moving one note, saving the ROM, then reading the saved file from disk and
  confirming the decompressed setup preserves the moved coordinate and struct count.

**Not verified:** physical Steam Deck / SteamOS, Game Mode input, hardware GPU
drivers, normal FUSE mounting, emulator gameplay after saving, or every
import/export/editor workflow. This is a runnable port preview, not a
claim that every inherited editor feature has been validated. Palette reduction
uses median cut and can produce different colors from the Windows build.

## Settings and troubleshooting

Application data: `~/.local/share/banjos-backpack/` (or under `XDG_DATA_HOME`).
This contains `resources/mw.ini`, temporary files, exports and `last-error.log`
after an error. Data remains outside the AppImage when you replace the download.
Mono may also create its normal per-user framework settings.

Run diagnostic checks in Konsole:

```sh
./Banjos-Backpack-Linux-preview-1-x86_64.AppImage --appimage-extract-and-run --self-test
```

`--smoke-test` opens the editor, renders the bundled model, checks its About
dialog, and closes. It requires a working graphical desktop. `--version` prints
the port version. Set `BB_DATA_HOME` to use an alternate writable data folder.

For a launch failure, capture terminal output:

```sh
./Banjos-Backpack-Linux-preview-1-x86_64.AppImage --appimage-extract-and-run > backpack.log 2>&1
```

## Source and credits

The separate source archive includes the modified C# source, build scripts,
dependency lockfile, upstream resource archive and AppImage runtime.
Build on x86-64 Linux with Python 3, `dpkg-deb`, and network access to the Ubuntu
archive: `sh rebuild.sh`. Dependencies are extracted locally; the build does
not use sudo or modify SteamOS's read-only system.

Original editor: Skill, Adam and Cooliscool; RareExports repository updates.
Editor license: GPL-3.0. N64 checksum adaptation credits Parasyte / Andreas
Sterbenz, GPL-2.0-or-later. Dependency copyright/license files are embedded
under `usr/share/doc/banjos-backpack/` inside the AppImage.

Sources:

- https://github.com/RareExports/Banjo-s-Backpack
- https://github.com/RareExports/Banjo-s-Backpack/releases/tag/1.0.5
- https://github.com/AppImage/type2-runtime/commit/75849dc
- https://n64dev.org/n64crc.html
