using System;
using BanjoKazooieLevelEditor;
class LockProbe
{
    static int Main()
    {
        try
        {
            AppPaths.Initialize();
            Console.WriteLine("LOCKED");
            Console.Out.Flush();
            Console.ReadLine();
            AppPaths.Shutdown();
            Console.WriteLine("RELEASED");
            Console.Out.Flush();
            Console.ReadLine(); // Stay alive to prove explicit release, not exit cleanup.
            return 0;
        }
        catch (Exception ex) { Console.Error.WriteLine(ex.Message); return 1; }
        finally { AppPaths.Shutdown(); }
    }
}
