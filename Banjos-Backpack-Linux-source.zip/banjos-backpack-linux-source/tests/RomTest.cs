using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using BanjoKazooieLevelEditor;
using OpenTK;
using OpenTK.Graphics.OpenGL;
class RomTest {
 static BindingFlags flags=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
 static object Get(object o,string n){return o.GetType().GetField(n,flags).GetValue(o);}
 static object Call(object o,string n,params object[] a){return Array.Find(o.GetType().GetMethods(flags),m=>m.Name==n && m.GetParameters().Length==a.Length).Invoke(o,a);}
 static Form1 editor;
 static string root;
 static bool closing;
 static bool saved;
 static int exitCode=1;
 static Control Find(Control c,string text){if(c is Button && c.Text.Replace("&","")==text)return c;foreach(Control sub in c.Controls){Control f=Find(sub,text);if(f!=null)return f;}return null;}
 [STAThread] static int Main(string[] args){
  root=Path.GetDirectoryName(Path.GetFullPath(args[0]));
  try {
   typeof(Form1).Assembly.GetType("BanjoKazooieLevelEditor.AppPaths").GetMethod("Initialize",BindingFlags.Static|BindingFlags.Public).Invoke(null,null);
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   editor=new Form1();
   ((OpenFileDialog)Get(editor,"openFileDialog1")).FileName=Path.GetFullPath(args[0]);
   var dialogs=new Timer{Interval=300};
   dialogs.Tick+=delegate{
    var forms=new System.Collections.Generic.List<Form>();foreach(Form f in Application.OpenForms)forms.Add(f);
    foreach(Form f in forms){
     if(f==editor || !f.Visible)continue;
     Console.WriteLine("DIALOG: "+f.Text);
     if(f.Text=="Extend Rom?" || f.Text=="Copy Rom?"){var b=Find(f,"Yes");if(b!=null)((Button)b).PerformClick();}
     else if(f.Text=="Open"){var b=Find(f,"Open");if(b!=null)((Button)b).PerformClick();}
     else if(f.Text=="Setup File"){
      var list=(ListView)Get(f,"fileFound_lv");
      for(int i=0;i<list.Items.Count;i++)if(list.Items[i].Text=="MM - Mumbo's Mountain"){
       list.Items[i].Selected=true;list.Items[i].Focused=true;((Button)Get(f,"ok_btn")).PerformClick();break;
      }
     } else if(f.GetType().GetField("msgbox_text",flags)!=null && (string)Get(f,"msgbox_text")=="Changes saved successfully"){saved=true;f.Close();}
     else if(f.GetType().GetField("msgbox_text",flags)!=null && ((string)Get(f,"msgbox_text")=="Rom Updated" || (string)Get(f,"msgbox_text")=="Contains lighting data not parsed by BB")){f.Close();}
     else if(!closing){Console.WriteLine("UNEXPECTED DIALOG: "+f.Text);foreach(Control c in f.Controls)Console.WriteLine(c.GetType().Name+": "+c.Text);for(Type t=f.GetType();t!=null;t=t.BaseType)foreach(var fld in t.GetFields(flags|BindingFlags.DeclaredOnly))if(fld.FieldType==typeof(string))Console.WriteLine("FIELD "+fld.Name+"="+fld.GetValue(f));closing=true;f.Close();}
    }
   };
   editor.Shown+=delegate{editor.BeginInvoke((MethodInvoker)delegate{
    try {
     dialogs.Start();
     Console.WriteLine("Opening ROM through editor dialog");editor.openRomAttempt();
     Console.WriteLine("ROM opened: "+Get(editor,"inRom"));
     var files=(IEnumerable)Get(editor,"sfl");foreach(object f in files)Console.WriteLine("LEVEL: "+Get(f,"name"));
     for(int lev=1;lev<=10;lev++)if(lev!=6){
       object fullStats=Call(Get(editor,"world"),"getLevelStats",lev,-1);
       Console.WriteLine("TOTAL level="+lev+" notes="+Get(fullStats,"note")+" jiggies="+Get(fullStats,"jiggy"));
       if((int)Get(fullStats,"note")!=100 || (int)Get(fullStats,"jiggy")!=10 || !Array.TrueForAll((bool[])Get(Get(editor,"world"),"jinjos"),x=>x))throw new Exception("Incorrect main-world totals: "+lev);
     }
     foreach(int lev in new[]{11,12,13}){
      object st=Call(Get(editor,"world"),"getLevelStats",lev,-1);
      if((int)Get(st,"note")!=0 || (int)Get(st,"jiggy")!=0)throw new Exception("Non-main-world totals were forced");
     }
     Console.WriteLine("Selecting Mumbo's Mountain");
     ((ToolStripMenuItem)Get(editor,"openSetupFileToolStripMenuItem")).PerformClick();
     Console.WriteLine("LEVEL LOADED");
     object world=Get(editor,"world");var objects=(IEnumerable)Get(world,"objects");int count=0;
     foreach(object o in objects){Console.WriteLine("OBJECT "+Get(o,"name"));count++;}
     Console.WriteLine("OBJECT COUNT "+count);
     foreach(DictionaryEntry entry in (IDictionary)Get(world,"MMLevelObjects")){int notes=0;foreach(object o in (IEnumerable)entry.Value)if((string)Get(o,"name")=="Note")notes++;Console.WriteLine("SCENE "+((int)entry.Key).ToString("X")+" NOTES "+notes);}
     var cam=(GLCamera)Get(editor,"BBCamera");cam.X=0;cam.Y=-2500;cam.Z=-6500;cam.Yaw=0;cam.Pitch=20;
     foreach(ObjectData obj in (IEnumerable)Get(world,"structs"))if(obj.name=="Note"){Console.WriteLine("NOTE MODEL "+obj.modelFile+" EXISTS "+File.Exists(obj.modelFile));cam.LookAt(new BanjoKazooieLevelEditor.Vector3(obj.locX,obj.locY,obj.locZ));break;}
     
     var stats=Get(editor,"ls");foreach(var f in stats.GetType().GetFields())Console.WriteLine("STAT "+f.Name+"="+f.GetValue(stats));
     foreach(var f in world.GetType().GetFields())if(f.Name.ToLower().Contains("jinjo"))Console.WriteLine("JINJO "+f.Name+"="+String.Join(",",(bool[])f.GetValue(world)));
     var editableStructs=(System.Collections.Generic.List<ObjectData>)Get(world,"structs");
     int ni=editableStructs.FindIndex(o=>o.name=="Note");var removedNote=editableStructs[ni];editableStructs.RemoveAt(ni);
     if((int)Get(Call(world,"getLevelStats",1,0x9788),"note")!=99)throw new Exception("Deleting note did not update total");
     editableStructs.Insert(ni,removedNote);
     var editableObjects=(System.Collections.Generic.List<ObjectData>)Get(world,"objects");var backup=new System.Collections.Generic.List<ObjectData>(editableObjects);
     editableObjects.RemoveAll(o=>o.objectID==9 && (o.specialScript & 127)==12);
     var withoutHuts=Call(world,"getLevelStats",1,0x9788);
     if((int)Get(withoutHuts,"note")!=95 || (int)Get(withoutHuts,"jiggy")!=8 || ((bool[])Get(world,"jinjos"))[1])throw new Exception("Hut rewards did not update");
     editableObjects.Clear();editableObjects.AddRange(backup);
     editableObjects.RemoveAll(o=>o.objectID==8 && (o.specialScript & 127)==12);
     if((int)Get(Call(world,"getLevelStats",1,0x9788),"jiggy")!=9)throw new Exception("Conga reward did not update");
     editableObjects.Clear();editableObjects.AddRange(backup);
     Call(world,"getLevelStats",1,0x9788);
     Console.WriteLine("PASS: all nine worlds 100 notes / 10 Jiggies / five Jinjos; non-main areas remain zero; note, hut and Conga deletions update counts.");
     var gl=(GLControl)Get(editor,"LevelViewer");gl.MakeCurrent();
     Console.WriteLine("LEVEL ID="+Get(Get(editor,"selectedFile"),"levelID"));
     object core=Get(world,"core");object camera=Get(editor,"BBCamera");
     Call(core,"ClearScreenAndLoadIdentity");GL.PushMatrix();GL.LoadMatrix((float[])Call(camera,"GetWorldToViewMatrix"));Call(world,"Redraw",camera);GL.PopMatrix();
     Console.WriteLine("BEFORE HUD ERROR="+GL.GetError());
     Type ui=typeof(Form1).Assembly.GetType("BanjoKazooieLevelEditor.BBUI");
     ui.GetMethod("DrawStats",BindingFlags.Public|BindingFlags.Static).Invoke(null,new[]{stats});
     ui.GetMethod("DrawJinjos",BindingFlags.Public|BindingFlags.Static).Invoke(null,new object[]{gl.Width-325,2,Get(world,"jinjos")});
     foreach(var f in ui.GetFields(BindingFlags.NonPublic|BindingFlags.Public|BindingFlags.Static))if(f.Name.StartsWith("t_"))Console.WriteLine("HUDTEXTURE "+f.Name+"="+f.GetValue(null));
     Console.WriteLine("AFTER HUD ERROR="+GL.GetError());
     GL.Finish();GL.ReadBuffer(ReadBufferMode.Back);
     byte[] p=new byte[gl.Width*gl.Height*4];GL.ReadPixels(0,0,gl.Width,gl.Height,PixelFormat.Rgba,PixelType.UnsignedByte,p);
     using(var image=new Bitmap(gl.Width,gl.Height)){for(int y=0;y<gl.Height;y++)for(int x=0;x<gl.Width;x++){int i=(y*gl.Width+x)*4;image.SetPixel(x,gl.Height-y-1,Color.FromArgb(255,p[i],p[i+1],p[i+2]));}image.Save(Path.Combine(root,"mumbos-mountain.png"));}
     Console.WriteLine("CAPTURED");
     var structs=(System.Collections.Generic.List<ObjectData>)Get(world,"structs");
     ObjectData note=structs.Find(o=>o.name=="Note");short oldX=note.locX;note.locX=(short)(oldX+1);
     Call(editor,"save_tsmi_Click",null,EventArgs.Empty);
     if(!saved)throw new Exception("Save did not succeed");
     Type rh=typeof(Form1).Assembly.GetType("BanjoKazooieLevelEditor.RomHandler");
     rh.GetProperty("Rom").SetValue(null,File.ReadAllBytes((string)Get(editor,"inRom")),null);
     byte[] setupBytes=(byte[])rh.GetMethod("DecompressFileToByteArray").Invoke(null,new object[]{0x9788});
     object reader=Get(world,"setupFileReader");
     var reopened=(ArrayList)Call(reader,"ReadSetupFile",setupBytes,false);
     var reStructs=(System.Collections.Generic.List<ObjectData>)reopened[1];
     if(reStructs.Count!=structs.Count || reStructs.Find(o=>o.name=="Note").locX!=oldX+1)throw new Exception("Saved note did not round-trip");
     Console.WriteLine("PASS: moved note, saved ROM, re-read disk and decompressed setup; coordinates and struct count preserved.");exitCode=0;
    }catch(Exception ex){Console.WriteLine(ex);exitCode=1;}finally{dialogs.Stop();editor.Close();}
   });};
   Application.Run(editor);return exitCode;
  }catch(Exception e){Console.WriteLine(e);return 1;}
 }
}
