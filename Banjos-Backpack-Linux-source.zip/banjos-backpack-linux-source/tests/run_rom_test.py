"""Run ROM editing regression against a specified unpacked AppImage; never edits input ROM."""
import os,pathlib,subprocess,tempfile,struct,secrets,time,shutil,zipfile,sys
base=pathlib.Path(__file__).resolve().parents[1]
app=pathlib.Path(sys.argv[1]).resolve()
rom=pathlib.Path(sys.argv[2]).resolve()
deps=base/'build-deps/root'
work=base/'test-results'/('rom-'+secrets.token_hex(4));work.mkdir(parents=True)
if rom.suffix.lower()=='.zip':
    with zipfile.ZipFile(rom) as archive:
        name=next(n for n in archive.namelist() if n.lower().endswith('.z64'))
        (work/'test.z64').write_bytes(archive.read(name))
else:shutil.copy2(rom,work/'test.z64')
editor=app/'usr/lib/banjos-backpack'
env=os.environ.copy()
env.update(LD_LIBRARY_PATH=str(app/'usr/lib/native'),MONO_CFG_DIR=str(app/'etc'),MONO_PATH=str(editor)+':'+str(app/'usr/lib/mono/4.5'),FONTCONFIG_FILE=str(app/'etc/fonts/fonts.conf'),LIBGL_ALWAYS_SOFTWARE='1',BB_DATA_HOME=str(work/'data'))
mono=str(app/'usr/bin/mono-sgen')
(work/'resources').symlink_to(editor/'resources',target_is_directory=True)
refs=['System.Windows.Forms','System.Drawing']
args=[mono,str(deps/'usr/lib/mono/4.5/mcs.exe'),'-out:'+str(work/'RomTest.exe')]+['-r:'+x for x in refs]+['-r:'+str(editor/(x+'.dll')) for x in ['OpenTK','OpenTK.Compatibility','OpenTK.GLControl']]+['-r:'+str(editor/'BanjoKazooieLevelEditor.exe'),str(base/'tests/RomTest.cs')]
subprocess.run(args,env=env,check=True)
display=str(secrets.randbelow(20000)+1000);cookie=secrets.token_bytes(16);auth=work/'Xauthority'
fields=[b'',display.encode(),b'MIT-MAGIC-COOKIE-1',cookie]
auth.write_bytes(struct.pack('>H',65535)+b''.join(struct.pack('>H',len(f))+f for f in fields))
env.update(DISPLAY='127.0.0.1:'+display,XAUTHORITY=str(auth))
natives=work/'native';natives.mkdir()
for name in ['libXfont2.so.2','libfontenc.so.1','libxkbfile.so.1']:
    shutil.copy2(next(deps.rglob(name)).resolve(),natives/name)
xenv=env.copy();xenv['LD_LIBRARY_PATH']=str(natives)+':'+env['LD_LIBRARY_PATH']
xkb=pathlib.Path('/usr/bin/xkbcomp')
if not xkb.exists():xkb.symlink_to(deps/'usr/bin/xkbcomp')
with (work/'xvfb.log').open('w') as log:
    server=subprocess.Popen([str(deps/'usr/bin/Xvfb'),':'+display,'-screen','0','1280x800x24','+iglx','-nolisten','unix','-nolisten','local','-listen','tcp','-auth',str(auth),'-xkbdir',str(deps/'usr/share/X11/xkb')],env=xenv,stdout=log,stderr=log)
    try:
        time.sleep(2)
        assert server.poll() is None,(work/'xvfb.log').read_text()
        with (work/'rom-test.log').open('w') as output:
            result=subprocess.run([mono,str(work/'RomTest.exe'),str(work/'test.z64')],env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
        print('RESULT',result.returncode,'LOG',work/'rom-test.log',flush=True)
        print('\n'.join(line for line in (work/'rom-test.log').read_text().splitlines() if line.startswith(('PASS:', 'STAT ', 'LEVEL LOADED', 'BEFORE HUD', 'AFTER HUD'))))
        if result.returncode: print((work/'rom-test.log').read_text()[-3000:])
        sys.exit(result.returncode)
    finally:
        server.terminate();server.wait(timeout=10)
