"""Linux regression: lock lifetime and packaged GUI close/relaunch. Run after packaging."""
import os, pathlib, subprocess, tempfile, struct, secrets, time, select, shutil
base=pathlib.Path(__file__).resolve().parents[1]
app=base/'BanjoBackpack.AppDir'
deps=base/'build-deps/root'
env=os.environ.copy()
env.update(LD_LIBRARY_PATH=str(app/'usr/lib/native'),MONO_CFG_DIR=str(app/'etc'),MONO_PATH=str(app/'usr/lib/mono/4.5'),FONTCONFIG_FILE=str(app/'etc/fonts/fonts.conf'),LIBGL_ALWAYS_SOFTWARE='1')
mono=str(app/'usr/bin/mono-sgen')

def line(proc):
    if not select.select([proc.stdout],[],[],15)[0]: raise RuntimeError('Timed out waiting for lock probe')
    return proc.stdout.readline().strip()
with tempfile.TemporaryDirectory(prefix='bb-relaunch-') as tmp:
    tmp=pathlib.Path(tmp);env['BB_DATA_HOME']=str(tmp/'data')
    probe=tmp/'LockProbe.exe'
    subprocess.run([mono,str(deps/'usr/lib/mono/4.5/mcs.exe'),'-out:'+str(probe),str(base/'tests/LockProbe.cs'),str(base/'banjos-backpack/BanjoKazooieLevelEditor/Linux/AppPaths.cs')],env=env,check=True)
    (tmp/'resources').mkdir();(tmp/'resources/fixture.txt').write_text('test')
    def start(): return subprocess.Popen([mono,str(probe)],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    owner=start()
    try:
        assert line(owner)=='LOCKED'
        blocked=subprocess.run([mono,str(probe)],env=env,input='',capture_output=True,text=True,timeout=10)
        assert blocked.returncode==1 and 'already running' in blocked.stderr,blocked
        owner.stdin.write('\n');owner.stdin.flush()
        assert line(owner)=='RELEASED' and owner.poll() is None
        for i in range(3):
            other=start()
            try:
                assert line(other)=='LOCKED'
                other.communicate('\n\n',timeout=10)
                assert other.returncode==0
            finally:
                if other.poll() is None: other.kill();other.wait()
        print('PASS: concurrent rejection; explicit release while owner remains alive; three reacquisitions.',flush=True)
    finally:
        owner.communicate('\n',timeout=10)
    owner=start();assert line(owner)=='LOCKED';owner.kill();owner.wait()
    other=start();assert line(other)=='LOCKED';other.communicate('\n\n',timeout=10);assert other.returncode==0
    print('PASS: recovery after forced termination with the existing lock file.',flush=True)
    # Authenticated TCP X11 is necessary in the build sandbox (Unix sockets unavailable).
    display=str(secrets.randbelow(20000)+1000);cookie=secrets.token_bytes(16)
    auth=tmp/'Xauthority'
    fields=[b'',display.encode(),b'MIT-MAGIC-COOKIE-1',cookie]
    auth.write_bytes(struct.pack('>H',65535)+b''.join(struct.pack('>H',len(f))+f for f in fields))
    env.update(DISPLAY='127.0.0.1:'+display,XAUTHORITY=str(auth))
    natives=tmp/'native';natives.mkdir()
    for name in ['libXfont2.so.2','libfontenc.so.1','libxkbfile.so.1']:
        source=next(deps.rglob(name));shutil.copy2(source.resolve(),natives/name)
    xenv=env.copy();xenv['LD_LIBRARY_PATH']=str(natives)+':'+env['LD_LIBRARY_PATH']
    xkb=pathlib.Path('/usr/bin/xkbcomp')
    if not xkb.exists(): xkb.symlink_to(deps/'usr/bin/xkbcomp')
    with (tmp/'xvfb.log').open('w') as log:
        server=subprocess.Popen([str(deps/'usr/bin/Xvfb'),':'+display,'-screen','0','1280x800x24','+iglx','-nolisten','unix','-nolisten','local','-listen','tcp','-auth',str(auth),'-xkbdir',str(deps/'usr/share/X11/xkb')],env=xenv,stdout=log,stderr=log)
        try:
            time.sleep(2)
            assert server.poll() is None,(tmp/'xvfb.log').read_text()
            for i in range(3):
                result=subprocess.run([str(app/'AppRun'),'--smoke-test'],env=env,capture_output=True,text=True,timeout=40)
                print(result.stdout,flush=True)
                assert result.returncode==0,result.stderr
            print('PASS: three graphical open/close/reopen cycles using the same data directory.',flush=True)
        finally:
            server.terminate();server.wait(timeout=10)
