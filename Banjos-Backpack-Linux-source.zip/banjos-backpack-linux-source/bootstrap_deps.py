import concurrent.futures, hashlib, json, lzma, pathlib, re, subprocess, urllib.request
base = pathlib.Path(__file__).parent / 'build-deps'
base.mkdir(exist_ok=True)
root = base / 'root'
cache = base / 'cache'
cache.mkdir(exist_ok=True)
archive = 'https://archive.ubuntu.com/ubuntu/'
def download(url, dest):
    if not dest.exists():
        with urllib.request.urlopen(url, timeout=90) as r: dest.write_bytes(r.read())
    return dest
def index(component):
    p = download(archive+'dists/jammy/'+component+'/binary-amd64/Packages.xz', cache/(component+'.xz'))
    packages = {}
    for block in lzma.decompress(p.read_bytes()).decode().split('\n\n'):
        fields = dict(line.split(': ', 1) for line in block.splitlines() if ': ' in line and not line.startswith(' '))
        if 'Package' in fields: packages[fields['Package']] = fields
    return packages
lock = pathlib.Path(__file__).parent / 'packages.lock.json'
if lock.exists():
    selected = json.loads(lock.read_text())
else:
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        db = {}
        for data in pool.map(index, ['main', 'universe']): db.update(data)
    skip = set('libc6 libc-bin debconf debconf-2.0 perl perl-base python3 python3-minimal init-system-helpers dpkg adduser binutils binfmt-support mono-runtime ca-certificates ca-certificates-mono ucf procps systemd systemd-sysv libpam-systemd libnss-systemd fontconfig-config x11-common xfonts-utils libgl1-mesa-dri libglx-mesa0'.split())
    selected = {}
    def add(name):
        if name in selected or name in skip: return
        if name not in db: raise ValueError('Missing package '+name)
        f = db[name]; selected[name] = f
        for dep in (f.get('Pre-Depends','')+','+f.get('Depends','')).split(','):
            choices = [re.split(r'[ :(]', x.strip())[0] for x in dep.split('|') if x.strip()]
            if not choices: continue
            if any(n in skip for n in choices): continue
            target = next((n for n in choices if n in db), None)
            if target: add(target)
            else: print('Unresolved virtual dependency', choices, flush=True)
    for name in 'mono-runtime-sgen mono-devel mono-utils libgdiplus libopentk-cil-dev squashfs-tools xvfb xdotool p7zip-full patchelf libglu1-mesa fonts-dejavu-core'.split(): add(name)
print('Downloading',len(selected),'packages;',round(sum(int(f['Size']) for f in selected.values())/2**20),'MiB',flush=True)
def fetch(f):
    p = download(archive+f['Filename'],cache/pathlib.Path(f['Filename']).name)
    if hashlib.sha256(p.read_bytes()).hexdigest()!=f['SHA256']: raise ValueError('Checksum mismatch '+str(p))
    return p
with concurrent.futures.ThreadPoolExecutor(10) as pool:
    paths = list(pool.map(fetch,selected.values()))
print('Extracting',flush=True)
for p in paths:
    subprocess.run(['dpkg-deb','-x',str(p),str(root)],check=True,stdout=subprocess.DEVNULL)
(base/'packages.json').write_text(json.dumps(selected,indent=2))
print('Ready:',root,flush=True)
