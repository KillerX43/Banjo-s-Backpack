# Pinned graphics dependencies

These OpenTK 1.1 assemblies and Linux DLL maps were recovered byte-for-byte
from the working HUD/collectible-update AppImage (before the shutdown rebuild).
SHA256.json pins all six files. build_linux.py verifies and copies them; it
must not overwrite them from Ubuntu's libopentk packages. The Linux project
also references this directory.

Ubuntu's assemblies have the same 1.1.0.0 assembly version but different runtime
behavior: their GL error checks throw GraphicsErrorException when the legacy
level renderer emits GL_INVALID_OPERATION. This broke level rendering while
the startup model-only smoke test still passed. The supplied ROM regression
reproduced the failure with the replacement dependencies and passed after
restoring this set, without reverting the shutdown fixes.

The packaged OpenTK license is in usr/share/doc/banjos-backpack. No ROM assets
are included here.
