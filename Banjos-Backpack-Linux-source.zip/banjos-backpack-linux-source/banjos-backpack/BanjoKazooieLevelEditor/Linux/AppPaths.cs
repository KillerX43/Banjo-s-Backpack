using System;
using System.IO;

namespace BanjoKazooieLevelEditor
{
    internal static class AppPaths
    {
        public static string DataRoot { get; private set; }
        private static FileStream instanceLock;

        public static void Initialize()
        {
            if (instanceLock != null) throw new InvalidOperationException("Application paths are already initialized.");
            string xdg = Environment.GetEnvironmentVariable("XDG_DATA_HOME");
            if (String.IsNullOrEmpty(xdg) || !Path.IsPathRooted(xdg))
                xdg = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ".local/share");
            DataRoot = Environment.GetEnvironmentVariable("BB_DATA_HOME");
            if (String.IsNullOrEmpty(DataRoot)) DataRoot = Path.Combine(xdg, "banjos-backpack");
            DataRoot = Path.GetFullPath(DataRoot);
            Directory.CreateDirectory(DataRoot);
            // The legacy editor shares temporary filenames. Reject a second
            // process using this data directory rather than corrupting work.
            instanceLock = new FileStream(Path.Combine(DataRoot, ".instance.lock"), FileMode.OpenOrCreate,
                                          FileAccess.ReadWrite, FileShare.ReadWrite);
            try
            {
                instanceLock.Lock(0, 1);
            }
            catch (IOException ex)
            {
                Shutdown();
                throw new InvalidOperationException(
                    "Banjo's Backpack is already running or is still closing. " +
                    "Close the other copy before opening this one. If its window has disappeared, " +
                    "restart your device once to clear the older process.", ex);
            }
            try
            {
                foreach (string dir in new[] { "resources", "tmp", "out", "text", "text/out", "exports" })
                    Directory.CreateDirectory(Path.Combine(DataRoot, dir));
                string assets = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "resources");
                if (!Directory.Exists(assets)) throw new DirectoryNotFoundException("Editor resources are missing: " + assets);
                foreach (string file in Directory.GetFiles(assets, "*", SearchOption.AllDirectories))
                {
                    string relative = file.Substring(assets.Length + 1);
                    string target = Path.Combine(DataRoot, "resources", relative);
                    Directory.CreateDirectory(Path.GetDirectoryName(target));
                    if (!File.Exists(target)) File.Copy(file, target);
                }
                string ini = Path.Combine(DataRoot, "resources/mw.ini");
                if (!File.Exists(ini)) File.WriteAllText(ini, "NEAR:100\nFAR:35000\n");
                Directory.SetCurrentDirectory(DataRoot);
            }
            catch
            {
                Shutdown();
                throw;
            }
        }

        public static void Shutdown()
        {
            // Closing the descriptor releases its OS lock. Never unlink the
            // file: another process could otherwise lock a different inode.
            var heldLock = instanceLock;
            instanceLock = null;
            if (heldLock != null) heldLock.Dispose();
        }
    }
}
