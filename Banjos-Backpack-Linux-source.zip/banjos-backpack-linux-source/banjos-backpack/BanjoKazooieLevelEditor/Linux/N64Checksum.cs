// N64 checksum algorithm: Copyright (C) 2005 Parasyte, based on uCON64
// by Andreas Sterbenz. C# adaptation for this Linux port, 2026.
// SPDX-License-Identifier: GPL-2.0-or-later
// Reference: https://n64dev.org/n64crc.html
using System;
using System.IO;

namespace BanjoKazooieLevelEditor
{
    internal static class N64Checksum
    {
        private static uint Read(byte[] b, int i)
        { return ((uint)b[i] << 24) | ((uint)b[i+1] << 16) | ((uint)b[i+2] << 8) | b[i+3]; }
        private static uint Crc32(byte[] b, int start, int length)
        {
            uint crc = 0xffffffff;
            for (int i = start; i < start + length; i++)
            {
                crc ^= b[i];
                for (int j = 0; j < 8; j++) crc = (crc >> 1) ^ ((crc & 1) == 1 ? 0xedb88320u : 0u);
            }
            return ~crc;
        }
        public static int Detect(byte[] rom)
        {
            if (rom.Length < 0x101000 || Read(rom, 0) != 0x80371240)
                throw new InvalidDataException("A big-endian .z64 ROM of at least 0x101000 bytes is required.");
            switch (Crc32(rom, 0x40, 0xfc0))
            {
                case 0x6170a4a1: return 6101;
                case 0x90bb6cb5: return 6102;
                case 0x0b050ee0: return 6103;
                case 0x98bc2c86: return 6105;
                case 0xacc8580a: return 6106;
                default: throw new InvalidDataException("Unrecognized N64 boot code; the ROM checksum was not changed.");
            }
        }
        public static uint[] Calculate(byte[] rom, int cic)
        {
            if (rom.Length < 0x101000) throw new InvalidDataException("ROM is too short for checksum calculation.");
            uint seed;
            switch (cic)
            {
                case 6101: case 6102: seed = 0xf8ca4ddc; break;
                case 6103: seed = 0xa3886759; break;
                case 6105: seed = 0xdf26f436; break;
                case 6106: seed = 0x1fea617a; break;
                default: throw new ArgumentOutOfRangeException("cic");
            }
            unchecked
            {
                uint t1=seed, t2=seed, t3=seed, t4=seed, t5=seed, t6=seed;
                for (int i=0x1000; i<0x101000; i+=4)
                {
                    uint d=Read(rom,i);
                    if (t6+d<t6) t4++;
                    t6+=d; t3^=d;
                    int shift=(int)(d&31);
                    uint r=(d<<shift)|(d>>((32-shift)&31));
                    t5+=r;
                    t2^=t2>d ? r : t6^d;
                    t1+=cic==6105 ? Read(rom,0x750+(i&255))^d : t5^d;
                }
                if (cic==6103) return new[] { (t6^t4)+t3, (t5^t2)+t1 };
                if (cic==6106) return new[] { t6*t4+t3, t5*t2+t1 };
                return new[] { t6^t4^t3, t5^t2^t1 };
            }
        }
        public static void UpdateFile(string path)
        {
            // Read and validate before changing anything; only header bytes
            // 0x10..0x17 are written. FileShare.None excludes concurrent writes.
            using (var stream=new FileStream(path,FileMode.Open,FileAccess.ReadWrite,FileShare.None))
            {
                byte[] rom=new byte[0x101000];
                int read=0, n;
                while (read<rom.Length && (n=stream.Read(rom,read,rom.Length-read))>0) read+=n;
                if (read!=rom.Length) throw new InvalidDataException("ROM is too short.");
                uint[] crc=Calculate(rom,Detect(rom));
                stream.Position=0x10;
                foreach (uint value in crc)
                    for (int shift=24;shift>=0;shift-=8) stream.WriteByte((byte)(value>>shift));
                stream.Flush();
            }
        }
    }
}
