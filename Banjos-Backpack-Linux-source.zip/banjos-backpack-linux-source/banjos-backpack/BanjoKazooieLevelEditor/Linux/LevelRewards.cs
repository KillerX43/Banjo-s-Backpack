using System;
using System.Collections.Generic;

namespace BanjoKazooieLevelEditor
{
    // Standard-game scripted rewards, keyed by the game's persistent Jiggy IDs.
    // See REWARD-SOURCES.md. These supplement setup objects, not fixed HUD totals.
    internal static class LevelRewards
    {
        internal static void PairFlags(List<ObjectData> objects)
        {
            var paired = new HashSet<ObjectData>();
            foreach (var o in objects) o.flag = -1;
            foreach (var marker in objects)
            {
                if (marker.type != ObjectType.Flag) continue;
                foreach (var o in objects)
                {
                    if ((o.specialScript & 0x7f) != 12 ||
                        (o.objectID != 0x46 && o.objectID != 0x47 && o.objectID != 0x2d) || paired.Contains(o)) continue;
                    if (Math.Abs(o.locX - marker.locX) < marker.radius &&
                        Math.Abs(o.locY - marker.locY) < marker.radius &&
                        Math.Abs(o.locZ - marker.locZ) < marker.radius)
                    {
                        o.flag = (ushort)marker.objectID + (o.objectID == 0x46 ? 1 : 0);
                        paired.Add(o);
                        break;
                    }
                }
            }
        }

        internal static int Count(int level, List<ObjectData> objects, HashSet<int> scenes,
            bool[] jinjos, ref int notes)
        {
            var rewards = new HashSet<int>();
            int unflagged = 0;
            foreach (var o in objects)
            {
                if ((o.specialScript & 0x7f) == 12 && o.objectID == 0x46)
                {
                    if (o.flag >= 0) rewards.Add(o.flag); else unflagged++;
                }
            }
            Func<int,int> count = id => objects.FindAll(o => (o.specialScript & 0x7f) == 12 && o.objectID == id).Count;
            Action<int,int> actorReward = (id, reward) => { if (count(id) > 0) rewards.Add(reward); };
            switch (level)
            {
                case 1: // MM: hut rewards follow smash order, not hut identity.
                    int huts = count(9);
                    if (huts > 0) notes += 5;
                    if (huts >= 4) jinjos[1] = true;
                    if (huts >= 6) rewards.Add(5);
                    actorReward(0x11, 4); actorReward(0x57, 8);
                    actorReward(0xf, 9); actorReward(8, 10);
                    break;
                case 2:
                    actorReward(0x115, 0x14); actorReward(0xf4, 0x11);
                    break;
                case 3:
                    actorReward(0xf5, 0x16); actorReward(0x3c, 0x17);
                    actorReward(0x102, 0x1b);
                    if (scenes.Contains(0x22)) rewards.Add(0x1c);
                    break;
                case 4:
                    actorReward(0x14e, 0x20); actorReward(0x5b, 0x21);
                    actorReward(0x1fa, 0x22); actorReward(0x136, 0x24);
                    actorReward(0x1fb, 0x25); actorReward(0xe8, 0x26);
                    actorReward(0x27a, 0x27); actorReward(0x13a, 0x28);
                    foreach (var o in objects)
                        if ((o.specialScript & 0x7f) == 12 && o.objectID == 0xc)
                        {
                            int tier = (o.locY - 600) / 430;
                            if (tier == 2) notes += 5;
                            if (tier >= 5) rewards.Add(0x23);
                        }
                    break;
                case 5:
                    actorReward(0x160, 0x2a);
                    actorReward(0x160, 0x30); actorReward(0x160, 0x2c);
                    if (scenes.Contains(0x27)) rewards.Add(0x2d); // snowman model buttons
                    actorReward(0x1ea, 0x2e); actorReward(0x15f, 0x2f);
                    actorReward(0x124, 0x31); actorReward(0x1f3, 0x32);
                    break;
                case 7:
                    actorReward(0x118, 0x3e);
                    if (scenes.Contains(0x13)) rewards.Add(0x40); // floor matching puzzle
                    actorReward(0x130, 0x44); actorReward(0x131, 0x45); actorReward(0x147, 0x46);
                    break;
                case 8:
                    actorReward(0x2a1, 0x49); actorReward(0x2a8, 0x4a); actorReward(0x29d, 0x4d);
                    break;
                case 9:
                    actorReward(0x1cb, 0x53); actorReward(0x1c5, 0x54);
                    // Boom Box's existing Jiggy is paired with the same reward flag.
                    actorReward(0x281, 0x56);
                    break;
                case 10:
                    actorReward(0x3a, 0x60); actorReward(0x25, 0x63);
                    break;
            }
            int[] jinjoReward = { 0, 1, 0xb, 0x15, 0x1f, 0x29, 0, 0x3d, 0x47, 0x51, 0x5b };
            if (level > 0 && level < jinjoReward.Length && jinjoReward[level] != 0 && Array.TrueForAll(jinjos, x => x))
                rewards.Add(jinjoReward[level]);
            return rewards.Count + unflagged;
        }
    }
}
