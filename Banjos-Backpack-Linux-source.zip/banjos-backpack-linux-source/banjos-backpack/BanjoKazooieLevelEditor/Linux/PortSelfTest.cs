using System;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace BanjoKazooieLevelEditor
{
    internal static class PortSelfTest
    {
        private static void Require(bool condition, string description)
        { if (!condition) throw new Exception("Self-test failed: " + description); }
        public static int Run()
        {
            string dir=Path.Combine(Path.GetTempPath(), "backpack-tests-"+Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                foreach (int size in new[] { 1, 15, 16, 17, 257, 4096, 65537 })
                {
                    byte[] input=new byte[size];
                    new Random(size).NextBytes(input);
                    string source=Path.Combine(dir,"source file.bin"), packed=Path.Combine(dir,"packed.bin");
                    File.WriteAllBytes(source,input);
                    var codec=new GECompression();
                    Require(codec.CompressGZipFile(source,packed,false), "compression returned false");
                    byte[] data=File.ReadAllBytes(packed);
                    Require(data[0]==0x11 && data[1]==0x72 && data.Length%8==0,"1172 header/alignment");
                    int declared=(data[2]<<24)|(data[3]<<16)|(data[4]<<8)|data[5];
                    Require(declared==size,"1172 logical size");
                    codec.SetCompressedBuffer(data);
                    int outSize=0, consumed=0;
                    byte[] decoded=codec.OutputDecompressedBuffer(ref outSize,ref consumed);
                    Require(decoded!=null && decoded.Take(size).SequenceEqual(input),"upstream decompressor round trip "+size);
                }
                Console.WriteLine("PASS: 1172 compression/decompression, seven sizes including unaligned inputs.");
                byte[] rom=new byte[0x101000];
                for(int i=0;i<rom.Length;i++) rom[i]=(byte)(i*37+(i>>3));
                // Independently generated with Parasyte's C reference implementation.
                int[] cics={6101,6102,6103,6105,6106};
                uint[] a={0xf8ce4ddc,0xf8ce4ddc,0xa3946759,0xdf2af436,0x04100f9e};
                uint[] b={0x17343c46,0x17343c46,0x7eabc1cc,0x1986d147,0x6b392c78};
                for(int i=0;i<cics.Length;i++)
                {
                    uint[] crc=N64Checksum.Calculate(rom,cics[i]);
                    Require(crc[0]==a[i]&&crc[1]==b[i],"CIC "+cics[i]);
                }
                Console.WriteLine("PASS: five N64 checksum variants match independent C reference vectors.");
                using(var source=new Bitmap(32,32))
                {
                    for(int y=0;y<32;y++) for(int x=0;x<32;x++)
                        source.SetPixel(x,y,Color.FromArgb(x<2?0:255,x*8,y*8,(x+y)*4));
                    foreach(int colors in new[]{16,256}) using(var result=PaletteQuantizer.Reduce(source,colors))
                    {
                        Bitmap image=result;
                        var palette=ImageHandler.GetUniqueColors(ref image);
                        Require(palette.Count<=colors,"palette limit "+colors);
                        Require(result.Width==32&&result.Height==32,"image dimensions");
                    }
                }
                Console.WriteLine("PASS: 16/256-color texture reduction and image dimensions.");
                return 0;
            }
            finally { Directory.Delete(dir,true); }
        }
        public static void CheckWindow(Form form)
        {
            Control[] controls=form.Controls.Find("LevelViewer",true);
            Require(controls.Length==1,"OpenGL viewport exists");
            var gl=(GLControl)controls[0];
            gl.MakeCurrent();
            Require(!String.IsNullOrEmpty(GL.GetString(StringName.Version)),"OpenGL context");
            Console.WriteLine("PASS: editor window, menus and OpenGL context: "+GL.GetString(StringName.Version));
            GL.ClearColor(0.13f,0.17f,0.20f,1f);
            GL.Clear(ClearBufferMask.ColorBufferBit|ClearBufferMask.DepthBufferBit);
            var core=new Core();
            core.SetView(gl.Height,gl.Width);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();
            GL.Translate(0f,-50f,-400f);
            GL.Rotate(20f,0f,1f,0f);
            BoundingBox bounds=core.DrawModelFile(Path.Combine(AppPaths.DataRoot,"resources/banjo.mw"),0f,0f,0f,0,100f,0,false);
            Require(bounds.getSize()>0,"bundled Banjo model parsed");
            GL.Finish();
            byte[] pixels=new byte[gl.Width*gl.Height*4];
            GL.ReadPixels(0,0,gl.Width,gl.Height,PixelFormat.Rgba,PixelType.UnsignedByte,pixels);
            int changed=0;
            for(int i=4;i<pixels.Length;i+=4)
                if(pixels[i]!=pixels[0]||pixels[i+1]!=pixels[1]||pixels[i+2]!=pixels[2]) changed++;
            Require(changed>100,"model produces visible pixels");
            gl.SwapBuffers();
            Console.WriteLine("PASS: bundled Banjo model parses and renders ("+changed+" non-background pixels).");
            string screenshot=Environment.GetEnvironmentVariable("BB_SCREENSHOT");
            if(!String.IsNullOrEmpty(screenshot))
            {
                using(var picture=new Bitmap(gl.Width,gl.Height))
                {
                    for(int y=0;y<gl.Height;y++) for(int x=0;x<gl.Width;x++)
                    {
                        int p=(y*gl.Width+x)*4;
                        picture.SetPixel(x,gl.Height-1-y,Color.FromArgb(pixels[p+3],pixels[p],pixels[p+1],pixels[p+2]));
                    }
                    picture.Save(screenshot,System.Drawing.Imaging.ImageFormat.Png);
                }
            }
            using(var about=new AboutBox())
            {
                about.Show(form); Application.DoEvents();
                Require(about.Visible,"About dialog opens");about.Close();
            }
            Console.WriteLine("PASS: About dialog opens and closes.");
        }
    }
}
