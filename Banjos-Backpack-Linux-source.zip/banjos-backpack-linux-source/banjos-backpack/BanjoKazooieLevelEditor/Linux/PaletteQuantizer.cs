using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace BanjoKazooieLevelEditor
{
    // Deterministic, weighted median-cut RGBA palette reduction. Replaces the
    // mixed-mode, Windows/x86-only Magick.NET dependency.
    internal static class PaletteQuantizer
    {
        private sealed class Entry
        {
            public Color Color;
            public int Count;
            public int Channel(int c) { return c == 0 ? Color.R : c == 1 ? Color.G : c == 2 ? Color.B : Color.A; }
        }
        public static Bitmap Reduce(Bitmap source, int maxColors)
        {
            if (source == null) throw new ArgumentNullException("source");
            if (maxColors < 2 || maxColors > 256) throw new ArgumentOutOfRangeException("maxColors");
            var counts = new Dictionary<int, Entry>();
            for (int y = 0; y < source.Height; y++)
                for (int x = 0; x < source.Width; x++)
                {
                    Color c = source.GetPixel(x, y);
                    int key = c.ToArgb();
                    Entry e;
                    if (!counts.TryGetValue(key, out e)) counts[key] = e = new Entry { Color = c };
                    e.Count++;
                }
            if (counts.Count <= maxColors) return new Bitmap(source);
            var boxes = new List<List<Entry>> { counts.Values.OrderBy(e => e.Color.ToArgb()).ToList() };
            while (boxes.Count < maxColors)
            {
                int best = -1, channel = 0;
                long score = -1;
                for (int b = 0; b < boxes.Count; b++)
                {
                    if (boxes[b].Count < 2) continue;
                    long weight = boxes[b].Sum(e => (long)e.Count);
                    for (int c = 0; c < 4; c++)
                    {
                        long range = boxes[b].Max(e => e.Channel(c)) - boxes[b].Min(e => e.Channel(c));
                        long candidate = range * weight * (c == 3 ? 2 : 1);
                        if (candidate > score) { score = candidate; best = b; channel = c; }
                    }
                }
                if (best < 0) break;
                var box = boxes[best].OrderBy(e => e.Channel(channel)).ThenBy(e => e.Color.ToArgb()).ToList();
                long half = box.Sum(e => (long)e.Count) / 2, accumulated = 0;
                int split = 0;
                do { accumulated += box[split++].Count; } while (split < box.Count - 1 && accumulated < half);
                boxes[best] = box.GetRange(0, split);
                boxes.Add(box.GetRange(split, box.Count - split));
            }
            var mapping = new Dictionary<int, Color>();
            foreach (var box in boxes)
            {
                long total = box.Sum(e => (long)e.Count);
                int[] c = new int[4];
                for (int i = 0; i < 4; i++) c[i] = (int)(box.Sum(e => (long)e.Channel(i) * e.Count) / total);
                Color reduced = Color.FromArgb(c[3], c[0], c[1], c[2]);
                foreach (Entry e in box) mapping[e.Color.ToArgb()] = reduced;
            }
            var result = new Bitmap(source.Width, source.Height);
            for (int y = 0; y < source.Height; y++)
                for (int x = 0; x < source.Width; x++) result.SetPixel(x, y, mapping[source.GetPixel(x, y).ToArgb()]);
            return result;
        }
    }
}
