using System;
using System.IO;
using System.Windows.Forms;

namespace BanjoKazooieLevelEditor
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length > 0 && args[0] == "--version")
                {
                    Console.WriteLine("Banjo's Backpack 2.0.19 Linux preview 1, SteamOS setup/relaunch fix (upstream 89b308a)");
                    return 0;
                }
                if (args.Length > 0 && args[0] == "--self-test") return PortSelfTest.Run();
                AppPaths.Initialize();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.ThrowException);
                using (var form = new Form1())
                {
                    if (args.Length > 0 && args[0] == "--smoke-test")
                    {
                        var timer = new Timer { Interval = 3000 };
                        timer.Tick += delegate {
                            timer.Stop();
                            PortSelfTest.CheckWindow(form);
                            form.Close();
                        };
                        form.Shown += delegate { timer.Start(); };
                    }
                    Application.Run(form);
                }
                return 0;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine(ex);
                try
                {
                    if (AppPaths.DataRoot != null)
                        File.WriteAllText(Path.Combine(AppPaths.DataRoot, "last-error.log"), ex.ToString());
                    if (args.Length == 0)
                        MessageBox.Show(ex.Message + "\n\nDetails are in last-error.log in the application data folder.",
                                        "Banjo's Backpack", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch { }
                return 1;
            }
            finally
            {
                AppPaths.Shutdown();
            }
        }
    }
}
