# Scripted collectible accounting

Behavior references: https://github.com/n64decomp/banjo-kazooie/tree/9db90a003fff15d13d29505d571aff2543b50383

- include/enums.h: persistent Jiggy IDs and world assignments.
- src/core2/ch/jiggy.c: stored region flag + 1 gives the Jiggy reward ID.
- src/MM/ch/{hut,juju,orangepad,lmonkey,conga}.c: hut order, green Jinjo,
  notes and the five scripted MM Jiggy rewards.
- src/TTC/ch/{treasure,blubber}.c.
- src/core2/ch/crab.c; src/CC/ch/tooth.c; src/CC/ma/{clanker,clankerrings}.c.
- src/BGS/ch/{mudhut,pinkegg,croctus,frogminigame,swampswitch,tanktup,tiptup}.c
  and src/BGS/mrvileminigame.c.
- src/FP/ma/{snowbutton,snowy,slalom}.c and src/FP/ch/{boggy1,bearcub,xmastree,wozzasjig}.c.
- src/GV/matchinggame.c; src/GV/ch/{grabba,gobirock,gobi2,ancientone}.c.
- src/CCW/ch/{beanstalk,outsideautumnnabnut,cutsceneadulteyrie}.c.
- src/RBB/ch/{anchorctrl,whistlectrl,bossboombox}.c.
- src/MMM/ch/cemetarypot.c and src/MMM/code_3420.c.

The C# implementation adds reward IDs for known actor/map scripts and unions
those IDs with placed Jiggies' flags. It does not clamp counters to 100/10.
The editor's existing spatial flag-pairing convention is retained. Accounting
is for the standard game scripts; it is not an emulator or a complete model of
puzzle reachability in arbitrary modified levels. The reference game source and
user ROM are not distributed with this port.
