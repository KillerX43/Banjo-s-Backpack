import hashlib, json, os, pathlib, shutil, subprocess, xml.etree.ElementTree as ET
base=pathlib.Path(__file__).parent
repo=base/'banjos-backpack'
deps=base/'build-deps/root'
out=repo/'bin/Linux'
out.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
env['LD_LIBRARY_PATH']=':'.join(str(deps/p) for p in ['usr/lib','usr/lib/x86_64-linux-gnu','lib/x86_64-linux-gnu'])
env['MONO_CFG_DIR']=str(deps/'etc')
mono=str(deps/'usr/bin/mono-sgen')
framework=deps/'usr/lib/mono/4.5'
args=['-noconfig','-nostdlib+','-langversion:latest','-target:winexe','-optimize+','-debug','-out:'+str(out/'BanjoKazooieLevelEditor.exe'),'-win32icon:'+str(repo/'bb.ico')]
for name in ['mscorlib','System','System.Core','System.Data','System.Design','System.Drawing','System.Windows.Forms','System.Xml','System.Configuration']:
    args.append('-r:'+str(framework/(name+'.dll')))
# Use the graphics assemblies verified with the editor, not distro replacements
# with the same assembly version but different GL error-checking behavior.
linux_libs=repo/'lib/Linux'
for name,digest in json.loads((linux_libs/'SHA256.json').read_text()).items():
    if hashlib.sha256((linux_libs/name).read_bytes()).hexdigest()!=digest:
        raise RuntimeError('Pinned graphics dependency checksum mismatch: '+name)
for name in ['Globalizer','OpenTK','OpenTK.Compatibility','OpenTK.GLControl']:
    lib=(repo/'lib'/(name+'.dll')) if name=='Globalizer' else linux_libs/(name+'.dll')
    args.append('-r:'+str(lib))
    shutil.copy2(lib,out)
    config=lib.with_suffix('.dll.config')
    if config.exists(): shutil.copy2(config,out)
ns={'m':'http://schemas.microsoft.com/developer/msbuild/2003'}
project=ET.parse(repo/'BB.Linux.csproj')
for elem in project.findall('.//m:EmbeddedResource',ns):
    src=repo/elem.attrib['Include'].replace('\\','/')
    res=out/(src.stem+'.resources')
    if not res.exists() or res.stat().st_mtime<src.stat().st_mtime:
        subprocess.run([mono,str(framework/'resgen.exe'),str(src),str(res)],env=env,check=True,stdout=subprocess.DEVNULL)
    relative=src.relative_to(repo).with_suffix('.resources')
    args.append('-resource:'+str(res)+','+'.'.join(relative.parts))
for elem in project.findall('.//m:Compile',ns):
    pattern=elem.attrib['Include'].replace('\\','/')
    args.extend(str(p) for p in sorted(repo.glob(pattern)))
subprocess.run([mono,str(framework/'mcs.exe')]+args,env=env,check=True)
shutil.copytree(base/'upstream-release/extracted/resources',out/'resources',dirs_exist_ok=True)
# A release developer's local paths must not become a first-run user's settings.
(out/'resources/mw.ini').write_text('NEAR:100\nFAR:35000\n')
print('Built',out/'BanjoKazooieLevelEditor.exe')
